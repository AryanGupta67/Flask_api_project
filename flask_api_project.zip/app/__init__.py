from flask import Flask
from .routes import main_bp
from .errors import register_error_handlers

def create_app():
    app = Flask(__name__)
    app.register_blueprint(main_bp)
    register_error_handlers(app)
    return app
