from flask import Blueprint, jsonify, request

main_bp = Blueprint("main", __name__)

@main_bp.route("/api/greet", methods=["GET"])
def greet():
    name = request.args.get("name")
    if not name:
        return jsonify({"error": "Missing name parameter"}), 400
    return jsonify({"message": f"Hello, {name}!"})
