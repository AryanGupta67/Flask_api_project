# Flask REST API Project

## Features
- Python 3.x + Flask
- REST API Endpoint: `/api/greet`
- Clean structure and modular design
- Error handling included

## Setup Instructions

### 1. Clone the project or unzip the folder
```bash
cd flask_api_project
```

### 2. Create virtual environment (optional but recommended)
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the application
```bash
python run.py
```

## API Usage

### `GET /api/greet`

#### Query Parameters:
- `name` (string): Name of the person

#### Example:
```bash
curl "http://127.0.0.1:5000/api/greet?name=Aryan"
```

#### Response:
```json
{
  "message": "Hello, Aryan!"
}
```
